(function(angular) {
    var myApp = angular.module('extApp', []);
})(window.angular);

